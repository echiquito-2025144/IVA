Sistema de Facturación Interactiva - TypeScript
Este proyecto consiste en un sistema modular desarrollado en TypeScript y ejecutado sobre el entorno de Node.js. La aplicación permite calcular de forma automática el subtotal, el Impuesto al Valor Agregado (IVA) correspondiente al 12% y el total general de una venta mediante un flujo de preguntas interactivas en la terminal de comandos.

Estructura del Proyecto
El código fuente está organizado bajo un enfoque modular, separando la lógica matemática de negocio de la interfaz de interacción con el usuario:

src/calculo.ts: Módulo de funciones puras encargado de procesar las operaciones aritméticas de facturación.

src/index.ts: Punto de entrada de la aplicación. Controla el flujo asíncrono, la captura de datos en la consola mediante el sistema de lectura y las validaciones de seguridad.

dist/: Directorio autogenerada que contiene el código JavaScript compilado resultante, listo para su ejecución.

Instalación y Configuración
Para inicializar el proyecto en un entorno local, se deben seguir los siguientes pasos:

Instalación de dependencias: Ejecutar el siguiente comando en la raíz del proyecto para instalar el compilador de TypeScript y las definiciones de tipo globales para Node.js:

Bash
pnpm install
Compilación del código fuente: Transpilar los archivos de TypeScript hacia el directorio de distribución ejecutable mediante el comando:

Bash
pnpm build
Modo de Uso
Para poner en marcha el sistema interactivo, se debe ejecutar el siguiente comando en la terminal:

Bash
pnpm start
Ejemplo del flujo de ejecución en la terminal:
Plaintext
=======================================================
             SISTEMA DE FACTURACIÓN INTERACTIVO        
=======================================================
 -> Ingrese el precio unitario del producto (Q): 150.50
 -> Ingrese la cantidad de unidades: 3
=======================================================

 >>> DETALLE DE LA FACTURA:
 Cantidad de productos : 3
 Precio Unitario      : Q150.50
-------------------------------------------------------
 Subtotal             : Q451.50
 IVA (12%)            : Q54.18
-------------------------------------------------------
 TOTAL A PAGAR        : Q505.68
=======================================================
Documentación de las Funciones (API de Módulos)
El módulo localizado en src/calculo.ts expone las funciones detalladas a continuación, las cuales incorporan comentarios estructurados bajo el estándar JSDoc:

1. calcularSubtotal
Definición: (precioUnitario: number, cantidad: number) => number

Descripción: Determina el costo total bruto multiplicando el precio individual del artículo por la cantidad de unidades solicitadas.

Parámetros:

precioUnitario: Valor numérico decimal que representa el costo unitario del producto.

cantidad: Valor numérico entero que representa las piezas adquiridas.

2. calcularIVA
Definición: (subtotal: number) => number

Descripción: Aplica la tasa impositiva fija del 12% sobre el monto base del subtotal proporcionado.

Parámetros:

subtotal: Base imponible de la transacción sobre la cual se calcula el impuesto.

3. calcularTotal
Definición: (subtotal: number, iva: number) => number

Descripción: Agrega de forma matemática el valor de la base imponible y el importe neto del impuesto previamente calculado para obtener el saldo final.

Parámetros:

subtotal: Monto base de la operación sin impuestos.

iva: Valor económico del impuesto determinado.

Tecnologías Utilizadas
Lenguaje: TypeScript (Configuración en modo estricto)

Entorno de Ejecución: Node.js

Gestor de Paquetes: pnpm

Módulos del Sistema: node:readline/promises y node:process (Gestión asíncrona de flujos de entrada y salida)