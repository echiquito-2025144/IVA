/**
 * Constante global para la tasa del IVA (12% expresado en decimal)
 */
const TASA_IVA = 0.12;

/**
 * Calcula el subtotal de un producto multiplicando el precio unitario por la cantidad.
 */
export const calcularSubtotal = (precioUnitario: number, cantidad: number): number => {
    return precioUnitario * cantidad;
};

/**
 * Calcula el valor del IVA a partir de un monto base (subtotal).
 */
export const calcularIVA = (subtotal: number): number => {
    return subtotal * TASA_IVA;
};

/**
 * Calcula el total final sumando el subtotal y el valor del IVA correspondiente.
 */
export const calcularTotal = (subtotal: number, iva: number): number => {
    return subtotal + iva;
};