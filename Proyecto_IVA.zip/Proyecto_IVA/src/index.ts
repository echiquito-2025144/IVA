// Importación corregida en singular y con la extensión requerida .js
import { calcularSubtotal, calcularIVA, calcularTotal } from './calculo.js';
import * as readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';

async function iniciarSistema() {
    const rl = readline.createInterface({ input, output });

    console.log("\n=======================================================");
    console.log("             SISTEMA DE FACTURACIÓN INTERACTIVO        ");
    console.log("=======================================================");

    try {
        const respuestaPrecio = await rl.question(' -> Ingrese el precio unitario del producto (Q): ');
        const precio = parseFloat(respuestaPrecio);

        const respuestaCantidad = await rl.question(' -> Ingrese la cantidad de unidades: ');
        const cantidad = parseInt(respuestaCantidad, 10);

        console.log("=======================================================");

        if (isNaN(precio) || isNaN(cantidad) || precio < 0 || cantidad <= 0) {
            console.log("\n [!] Error: Por favor ingresa valores numéricos válidos y mayores a cero.");
        } else {
            const subtotal = calcularSubtotal(precio, cantidad);
            const iva = calcularIVA(subtotal);
            const total = calcularTotal(subtotal, iva);

            console.log(`\n >>> DETALLE DE LA FACTURA:`);
            console.log(` Cantidad de productos : ${cantidad}`);
            console.log(` Precio Unitario      : Q${precio.toFixed(2)}`);
            console.log("-------------------------------------------------------");
            console.log(` Subtotal             : Q${subtotal.toFixed(2)}`);
            console.log(` IVA (12%)            : Q${iva.toFixed(2)}`);
            console.log("-------------------------------------------------------");
            console.log(` TOTAL A PAGAR        : Q${total.toFixed(2)}`);
        }

    } catch (error) {
        console.log(" [!] Ocurrió un error al procesar los datos.");
    } finally {
        rl.close();
        console.log("=======================================================\n");
    }
}

iniciarSistema();